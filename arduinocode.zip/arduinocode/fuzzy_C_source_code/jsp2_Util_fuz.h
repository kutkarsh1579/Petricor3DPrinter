//JOHN PALMISANO		5-24-04
//for fuzzy
//WORKS ON NEW CEREBELLUM

#include <16F877.h>
#include <877reg.h>
#include "adc.h"

#fuses HS, NOWDT
#use rs232(baud=115200, parity=N, bits=8, xmit=PIN_C6, rcv=PIN_C7)

///////////////////MY VARIABLES//////////////////////////////////
//orientation values
long int compass_angle=0;//angle from compass
signed long int rotate_speed;//angle speed to turn at (continuous motion) to reach point_to
long int trans_angle;//angle to translate wrt compass_Angle
signed int trans_speed=1;//translation speed
long int angleDiff;//trans_angle-compass_Angle

//trig lookup table variables
//table of cosine from 0->90 degrees in 10 deg increments, the inverse direction for sine
signed int angtable[10]={100,99,94,87,77,64,50,34,17,0};//multiplied by 10 so no doubles

//wheel speeds
signed int top=0;
signed int left=0;
signed int right=0;
signed int bottom=0;

//misc variables
int i=0, j=0;
//////////////////////////////////////////////////////////////////

// for LEDs
#define YELLOW 1
#define GREEN 0

// for buttons
#define A 0
#define B 1

// ADC ports
#define A0 0
#define A1 1
#define A2 2
#define A3 3
#define A5 4
#define E0 5
#define E1 6
#define E2 7

// Specify Servo Port
#define SERVOPORT 3
#define SERVO_PORT PORTD
#define SERVO_TRIS TRISD

char servo_state = 0;
char servo_count = 0;
char servo_curr = 0;
char servo_switch = 1;
char servo_pos[8] = {0,0,0,0,0,0,0,0};
char servo_free = 0;

#INT_RTCC
// servo control variables
void servo_isr(void) {

	servo_free = 0;

	if (servo_state == 1) {
		// next intr in 0.6 ms
		TMR0 = 180;

		if (servo_pos[servo_curr] != 0)
			SERVO_PORT = SERVO_PORT | servo_switch; // output hi
		servo_switch = servo_switch << 1;

		if (servo_switch == 0) servo_switch = 1;

		servo_state = servo_state + 1;
		servo_count = 0;
		servo_free = 1;
	}

	else if (servo_state == 2) {
		TMR0 = 255 - servo_pos[servo_curr];
		servo_state = 3;
	}

	else if (servo_state == 3) {
		SERVO_PORT = 0; // output lo
		TMR0 = servo_pos[servo_curr];
		servo_curr = servo_curr + 1;
		servo_curr = servo_curr & 0x07;
		servo_state = 1;
	}
	T0IF = 0;
}

inline void servo_init(void) {
    OPTION_REG = 132; // bit 7 = 1 for portB pull-up and bit2 is for prescaler
	// TMR0 @ 1:32, prescaler to timer0 (for servo control)
    TRISD = 0; // port D as outputs	for servo commands!
    T0IE = 1; //T0IE = 1 ie enable TMR0 overflow bit - T0IE is bit 5

	servo_state = 1;
	GIE = 1;

    delay_ms(1);
}

// turn a specified(0 or 1) LED on.
void LEDon(int which)
{
  /*if(which == 0)
    output_high(PIN_B0);

  else
    output_high(PIN_B2);*/
  if(which == 1)
    output_high(PIN_B2);
}

// turn a specified(0 or 1) LED off.
void LEDoff(int which)
{
  /*if(which == 0)
    output_low(PIN_B0);

  else
    output_low(PIN_B2);*/
  if(which == 1)
    output_low(PIN_B2);
}

//sets speed of each servo from slide calcs
void makego(signed int top, signed int left, signed int right, signed int bottom)
{//0->30 for full speed====127->167
  int pulseTop;
  int pulseLeft;
  int pulseRight;
  int pulseBottom;

  // converts -100 to 100 to the full range of servo motion
  // centers at 127, the 0 spot of a servo.
  pulseTop = 127 - (signed int)(2*(signed long int)top)/5;
  pulseLeft = 127 - (signed int)(2*(signed long int)left)/5;
  pulseRight = 127 - (signed int)(2*(signed long int)right)/5;
  pulseBottom = 127 - (signed int)(2*(signed long int)bottom)/5;

  // sets the given servo to the given position.
  servo_pos[0]=pulseTop+4;//modified because servo misaligned
  servo_pos[1]=pulseLeft+3;
  servo_pos[2]=pulseRight+4;
  servo_pos[3]=pulseBottom+3;
}

//trig lookup table, type 0 for cos, 1 for sin, degrees is from 0->360
signed int anglookuptable(long int degrees, int type)
{//{100,99,94,87,77,64,50,34,17,0}
   signed int c=1;
   signed int s=1;

	i=(int)(degrees/10);//includes 0 to 90 degrees

	if(i>9 && i<=18)//between 91 and 180
      {
		i=18-i;
      c=-1;
      }
	if(i>18 && i<=27)//between 181 and 270
      {
		i=i-18;
      c=-1;
      s=-1;
      }
	if(i>27 && i<=36)//between 271 and 360
      {
		i=36-i;
      s=-1;
      }

	if(type==1)//cosine
      {
      //printf("%d\r\n",c*angtable[i]);
		return c*angtable[i];
      }
	else//sine
      {
      //printf("%d\r\n",s*angtable[9-i]);
		return s*angtable[9-i];
      }
}

//rotate_speed: neg for left, pos for right
//trans_angle: 0->359 angle to translate at
void orient(signed int rotate_speed, long int trans_angle, signed int trans_speed)
{
   signed int fastestspeed=0;
   signed long int overflowthresh=115;
	//compass();//read in compass angle (read last cause prone to oscillation)

   //this line is incorrect, needs to account for negatives
	angleDiff=trans_angle-compass_Angle;//calculating angle to turn to wrt compass

	//translation (multiplied by 100 and divided by 100)//finished
	top=anglookuptable(angleDiff,0);//cosine
	left=anglookuptable(angleDiff,1);//sine
	right=-anglookuptable(angleDiff,1);//sine
	bottom=-anglookuptable(angleDiff,0);//cosine

	//rotate at a speed and direction, positive for left, neg for right
   //finding highest speed (to max out rotation speed)
   if(abs(top)>abs(fastestspeed))
      fastestspeed=top;
   if(abs(left)>abs(fastestspeed))
      fastestspeed=left;
   if(abs(right)>abs(fastestspeed))
      fastestspeed=right;
   if(abs(bottom)>abs(fastestspeed))
      fastestspeed=bottom;
   if((rotate_speed+(signed long int)fastestspeed)>overflowthresh)//set new rotate speed so no positive overflows
      rotate_speed=overflowthresh-(signed long int)fastestspeed;
   if((rotate_speed+(signed long int)fastestspeed)<-overflowthresh)//set new rotate speed so no negative overflows
      rotate_speed=-overflowthresh-(signed long int)fastestspeed;
   top=top-(signed int)(rotate_speed);
   left=left-(signed int)(rotate_speed);
   right=right-(signed int)(rotate_speed);
   bottom=bottom-(signed int)(rotate_speed);

   //adjusting for speed

   //set final speeds
	makego(top, left, right, bottom);
   //printf("top:%d left:%d right:%d bottom:%d \r\n", top, left, right, bottom);
}

// takes a -90 to 90 angle, converts to servo 255 to 0
void scan(signed int angle)
{
  int pulseWS;

  // converts -100 to 100 to the full range of servo motion
  // centers at 127, the 0 spot of a servo.
  pulseWS = 127 + (int)((4*((signed long int)angle))/3);

  // sets the given servo to the given position.
  servo_pos[4]=pulseWS;//modified because servo misaligned
}

// read from a given analog port
unsigned int analog(int which)
{
	unsigned int sense;

	sense = adc_read(which);
	delay_ms(1);

	return sense;
}

inline int button(int which)
{
   int state;
   if(which == A)
	state = input(PIN_B4);
   //else//disabled to use B5 for interrupts
	//state = input(PIN_B5);

   return state;
}

inline void cereb_init()
{
  GIE = 1; // Enable Interrupts (servos only work with enabled interrupts)

  servo_init();  // Initialize servos
  servo_state = 1;  // Enable servos

  //setup_timer_2(T2_DIV_BY_16,255,1);//timer for the sonar
  setup_timer_1(T1_INTERNAL|T1_DIV_BY_8);//timer for the sonar (an overflow is 104.8576ms exactly)

  adc_init(0);

  //LEDoff(GREEN);
  LEDoff(YELLOW);

  delay_ms(1);
}
