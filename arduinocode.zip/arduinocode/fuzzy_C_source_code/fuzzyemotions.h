//every emotion has something to increase it, decrease, and something that it modifies

//boredom determined by change in sensor readings
void boredom()//low level
{
	//increase with slow movement
	//increases with small sensor readings (use avoidoldsum)

	//decrease with fast movement
	//decrease with large sensor readings (use avoidoldsum)

	//high boredom decreases sensor action


		//time=get_TIMER1();
		//printf("%lu\r\n",time);
}

//determined by energy being used and amount that is left
void energy()//low level
{
	//servos - total speed of all servos added
	//sensors - totals for each type of sensor currently being used
	//expected battery life - subtracts with time turned on (how do i track this? - maybe track # of cycles?)
}

//higher level emotion determined by lower levels
void explore()//high level
{

}

void fear()
{
	//avoid extremely close obstacles
}

void claustrophobia()
{
	//avoid being trapped in a confined area
}

void emotioncombine()
{
	boredom();
	energy();
	explore();
	fear();
	claustrophobia();
	emotioncombine();
	//all emotions combine to modify final heading
}
