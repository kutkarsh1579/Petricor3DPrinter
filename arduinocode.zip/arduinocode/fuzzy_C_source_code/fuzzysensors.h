//JOHN PALMISANO		5-24-04
//FOR NEW CEREBELLUM ONLY

//note: make totalangle a multiple of resolution or bad rounding will occur
#define resolution 33//larger number means more accurate, but also more ram used
#define totalangle 77//total angle that it turns, must be divisable by resolution/3
#define safety_angle 9//angle to avoid stuff at
#define avoiddistance 155//stays further away from objects when this number is smaller (non-linear!)

//sonar values
unsigned int distanceL;
unsigned int distanceM;
unsigned int distanceR;

//IR noise filtering threshold (higher values mean less smoothing)
int smooththresh=6;
//IR edge detection (higher values mean sharper edges required for detection)
int edgethresh=10;

//IRinterpretmap variables
int object_loc=resolution/2;
int empty_loc=resolution/2;
long int sum=0;
int avoidob=0;
int empspace=0;
long int objectold_sum=0;//stores highest value
long int emptyold_sum=10000;//stores lowest value
int amount_of_E=0;

//IR scanner variables
int map[resolution];
int direction=1;
int scanmod=18;

//lower numbers mean more empty space
void IRinterpretmap()//find masses of objects
{
	////////////////////find immediate obstacle code/////////
	objectold_sum=0;//stores highest value
	emptyold_sum=10000;//stores lowest value
   amount_of_E=0;//stores amount of empty space found clustered

	//warning: has preference for earlier readings when equality found
	for (i=1; i<(resolution-1); i++)
		{
		//sum=map[i-2]+map[i-1]+map[i]+map[i+1]+map[i+2];//add a space of nodes together
		sum=map[i-1]+map[i]+map[i+1];//add a space of nodes together

      //modify with sonar values:
      if (i<=resolution/3)
         sum=sum+(120-distanceR);
      else if (i<=resolution*2/3)
         sum=sum+(120-distanceM);
      else
         sum=sum+(120-distanceL);

      //finds obstacles
		if (sum>objectold_sum)//compare to find higher value
			{
			avoidob=i;
			objectold_sum=sum;
			}
      //find area of fewest stuff in the way
		if (sum<emptyold_sum)//compare to find lower value
			{
			empspace=i;
			emptyold_sum=sum;
			}
		}

	object_loc=(object_loc+2*avoidob)/3;//average with preference to newer value (cause of oscillation)
	empty_loc=(empty_loc+2*empspace)/3;//average with preference to newer value (cause of 0's and 1's)
}

void IRprintmap()//prints out a visual map . . . should improve later to interpolate edge directions . . .
{
	for(i=0;i<13;i++)//distance component (ignore above 60 for now)
		{
		for(j=0;j<resolution;j++)//horizontal component
			{
			if(object_loc==j && i==0)//where object to avoid is located
				printf("O");
			else if(empty_loc==j && i==0)//most empty space found
				printf("E");
			else if(map[j]>=i*10 && map[j]<=(i*10+9))//map a found object
				printf("=");
			else if(map[j]>(i*10+9))//space behind objects
				printf("-");
			else//empty space
				printf(" ");
			}
		printf("\r\n");
		}

	//print out scanned maps in number form
	/*i=0;
	while(i<resolution)
		{
		printf("%u ", map[i]);
		i++;
		}
	printf("\r\n");*/
}

//get 2D map of surroundings with IR
void scanner()
{
	//scan going the other direction
	if (direction==0)
		direction=1;
	else
		direction=0;

	if (direction==0)//scan clockwise (right)
		{
		for (i=0; i<resolution/3; i++)
			{
			//emergency();
			map[i]=analog(A3);// read scan value on middle
			map[i+(resolution/3)]=analog(A5);//read scan value on left side
			map[i+(resolution*2/3)]=analog(E0);//read scan value on right side
			scan(i*(totalangle/(resolution/3))-totalangle/3+scanmod);//turn servo to scan angle
			delay_ms(40);//servo reaction speed (60 degrees in 140ms)-> time/(resolution/3)
			}
		}
	else//direction=1 scan counterclockwise (left)
		{
		for (i=resolution/3; i>0; i--)
			{
			//emergency();//if really close reading, back up immediatly
			scan((i-1)*(totalangle/(resolution/3))-totalangle/3+scanmod);//turn servo to scan angle
			map[i-1]=analog(A3);// read scan value on right side
			map[i-1+(resolution/3)]=analog(A5);
			map[i-1+(resolution*2/3)]=analog(E0);
			delay_ms(40);//servo reaction speed (60 degrees in 140ms)
			}
		}
}

void IRedgedetect()//not quite sure how this is useful at the moment . . . but it will work
{
	//IRnoisefilter();//remove noise to prevent bad edge detection mojo

	for (i=1; i<(resolution); i++)
		{
		if(abs(map[i-1]-map[i])>edgethresh)
			i=0;//edge detected
		}
}

void compass()
{
	//get compass angle
}

//range, 140 inches gives an analog of about 10000
//conversion: (overflowsecs/overflowbit)/2*speedofsound*inchesconversion
//conversion: ((.105 / 65 534) / 2) * 1130 * 12 = 0.0108630634 ~1/93
//WARNING DO NOT SET ALL 3 PINS HIGH AT THE SAME TIME, IT DOESNT WORK
void sonar(unsigned int &distanceL, unsigned int &distanceM, unsigned int &distanceR)
{
   unsigned long int pingdelaytime=11000;//18ms max read time, 36ms time out for sonar (out of 65534 bit time)

	output_high(pin_D5);//set left sonar high
	delay_us(12);//ping TTL level pulse minimum is 10us
	output_low(pin_D5);//left sonar
   //while(analog(A0)<=100);//loop until recieve line goes high
   delay_us(210);//the sonar has a forced 100us pause
	set_TIMER1(0);//reset timer so no overflows
   while(get_TIMER1()<pingdelaytime && analog(A0)>100);//wait till output goes low or times out
   distanceL=get_TIMER1()/93;//store time it took to recieve return ping, and convert to inches
   delay_ms(22);//dissapation time for sound in a medium size area

   //--------------------------------------------------------------

	output_high(pin_D7);//set right sonar high
	delay_us(12);//ping TTL level pulse minimum is 10us
	output_low(pin_D7);//right sonar
   //while(analog(A2)<=100);//loop until recieve line goes high
   delay_us(210);//the sonar has a forced 100us pause
	set_TIMER1(0);//reset timer so no overflows
   while(get_TIMER1()<pingdelaytime && analog(A2)>100);//wait till output goes low or times out
   distanceR=get_TIMER1()/93;//store time it took to recieve return ping, and convert to inches
   delay_ms(22);//dissapation time for sound in a medium size area

   //--------------------------------------------------------------

	output_high(pin_D6);//set middle sonar high
	delay_us(12);//ping TTL level pulse minimum is 10us
	output_low(pin_D6);//middle sonar
   //while(analog(A1)<=100);//loop until recieve line goes high
   delay_us(210);//the sonar has a forced 100us pause
	set_TIMER1(0);//reset timer so no overflows
   while(get_TIMER1()<pingdelaytime && analog(A1)>100);//wait till output goes low or times out
   distanceM=get_TIMER1()/93;//store time it took to recieve return ping, and convert to inches


	printf("s dR: %u dM: %u dL: %u\r\n", distanceR, distanceM, distanceL);//print to test

   //reduce time delay here when code timing becomes more known
   delay_ms(46);//36ms maximum pulse time needed during a pulse + 10ms minimum between pulses
}
