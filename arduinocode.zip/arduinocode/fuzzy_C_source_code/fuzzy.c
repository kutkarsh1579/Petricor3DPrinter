//www.societyofrobots.com		5-24-04

//FOR NEW CEREBELLUM ONLY, PIC 16F877

      //////////////
      //////////////
      //improve so its always moving towards empty_loc even when it sees an object
      //later have the magnitude also modify speed
      //GETTING SONAR TO REGISTER PROPERLY IN THE PRINT/INTERPRET MAP FUNCTIONS
      //////////////
      //////////////

#include "jsp2_Util_fuz.h"
#include "fuzzyemotions.h"
#include "fuzzysensors.h"

//updates world info
void sensor_read()
{
   sonar(distanceL, distanceM, distanceR);//read in sonar, returns dist in cm
	scanner();//read IR into a 360 degree mapping
	//compass();
}

void rotpathplan()//later determined/modified by emotions, returns rotate_angle
{
   signed long int point_to;//angle to face

   //rotate so that scanner faces directly between O and E, preference towards E
   point_to=(((signed long int)object_loc+2*(signed long int)empty_loc)/3-(signed long int)resolution/2)*5;//also converts to an angle (sub res/2 and mult by 5)

   //calculates speed to rotate to point at a certain angle using rotation
   //rotate_speed: neg for left, pos for right
   rotate_speed=point_to-(signed long int)compass_Angle;//note: determines speed not angle!!!
   if(rotate_speed<-180)
      rotate_speed=360+rotate_speed;
   if(rotate_speed>180)
      rotate_speed=-(360-rotate_speed);
}

//translate using potential field
void transpathplan()//later determined/modified by emotions, returns trans_angle
{
   //object_loc //location of object to avoid
   //objectold_sum //amplitude of object
   //empty_loc //location of empty space to go towards
   //emptyold_sum //amplitude of empty space

   signed long int magnitude;
   long int dirangle;
   signed long int trappedthresh=150;//threshhold to determine if object is in the way

   //mag=(thresh-Eamp)(res/2-abs(Eloc))-Oamp(res/2-abs(Oloc))
   magnitude=(trappedthresh-(signed long int)emptyold_sum)*((signed long int)resolution/2-abs((signed long int)empty_loc-(signed long int)resolution/2))
         -(signed long int)objectold_sum*((signed long int)resolution/2-abs((signed long int)object_loc-(signed long int)resolution/2));
   if(magnitude<-120)//make sure no crazy overflows
      magnitude=-120;
   if(magnitude>120)
      magnitude=120;

   //*5/2 converts to 0->360
   if (magnitude<0)//if negative because obstacle in way (and to convert to angle)
      {
      //if ((object_loc-resolution/2)<0) //if negative (object_loc on left)
         //dirangle=(long int)(360+(object_loc-resolution/2)*5/2-180);
      //else //if positive (empty_loc on right)
         dirangle=(long int)(((signed long int)object_loc-(signed long int)resolution/2)*5/2+180);
      }
   else //if positive since no major obstacle in the way
      {
      if (((signed int)empty_loc-(signed int)resolution/2)<0) //if negative (empty_loc on left)
         dirangle=(long int)(((signed long int)empty_loc-(signed long int)resolution/2)*5/2+360);
      else //if positive (empty_loc on right)
         dirangle=(long int)(((signed long int)empty_loc-(signed long int)resolution/2)*5/2);
      }

      trans_angle=dirangle;
      trans_speed=(signed int)magnitude;
}

void interpretworld()
{
	IRinterpretmap();
   //transpathplan();
   //rotpathplan();
}

//note to translate, the 2 servos on the right of direction of travel are negative speeds
void main()
{
long int t=0;
   //initialization
   cereb_init();
   scan(-totalangle/3+scanmod);
   while(!button(A));

	while(1)//code below here only
		{
		sensor_read();//sense
		interpretworld();//plan
      //orient(rotate_speed,trans_angle,0);//speed modified in transpathplan

      //printf("rot:%ld tangle:%ld magnitude:%d\r\n", rotate_speed, trans_angle, trans_speed);
      IRprintmap();

		delay_ms(200);

      //circle test
		/*printf("%ld\r\n",t);
      orient(0,t,0);//rotate_speed, trans_angle, trans_speed
		delay_ms(11);
      t++;
      if (t==360)
         t=0;*/
		}
    while(1);
}
